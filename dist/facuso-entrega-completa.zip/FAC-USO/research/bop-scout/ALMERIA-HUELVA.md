# Fuentes automáticas verificadas: BOP de Almería y Huelva

Comprobado el 18/10/2026 contra los portales públicos oficiales. Las fechas de los ejemplos son de publicación, no plazos de solicitudes.

## Huelva: JSON oficial

La [página oficial del BOP](https://sede.diphuelva.es/opencms/system/modules/gsede/elements/contenido/BOP.jsp) enlaza a `https://s2.diphuelva.es/servicios/bope_web/UltimoBop`. Su código JavaScript llama a:

```text
POST https://s2.diphuelva.es/lib/bope/anuncios_bop/ajaxAnuncios.php
Content-Type: application/x-www-form-urlencoded; charset=UTF-8

tipo=1&fecha=2026-10-18     # último BOP publicado, aunque no haya edición hoy
tipo=2&fecha=2026-10-16     # edición de un día concreto, formato AAAA-MM-DD
```

La respuesta es JSON; campos útiles: `success`, `TieneAnuncios`, `fecha_publicacion`, `Indice.num_bop` y `Anuncios[]`. Cada aviso tiene `id_anuncio`, `fecha_publicacion`, `documento`, `entidad_anunciante`, `titulo`, `num_expe`, `Categoria`, `Seccion`. El PDF oficial se forma uniendo `https://s2.diphuelva.es/portalweb/bope/anuncios/` y `documento`. No hace falta descargar PDFs para detectar avisos; sí conviene enlazarlos. `tipo=2` dio BOP 200, 14 avisos el 16/10; BOP 199, 9 avisos el 15/10; el 17/10 devolvió `success=false` y ningún aviso.

Ejemplos del 16/10/2026:

| ID | Entidad y título | PDF |
| --- | --- | --- |
| 11448 | Ayuntamiento de El Campillo — Bases y convocatoria de bolsa de Operario de Servicios Múltiples (Electricista) | [Anuncio 381153](https://s2.diphuelva.es/portalweb/bope/anuncios/Anuncio_381153_BOP-200_2026.pdf) |
| 11450 | Ayuntamiento de Gibraleón — Concurso-oposición por promoción interna de una plaza de Oficial de Jardinería | [Anuncio 379834](https://s2.diphuelva.es/portalweb/bope/anuncios/Anuncio_379834_BOP-200_2026.pdf) |

El primer PDF respondió `HEAD 200`, `Content-Type: application/pdf`, 118046 bytes.

**Incidente de entorno:** El DNS local no resuelve `s2.diphuelva.es` ni otros subdominios de `diphuelva.es`; Chrome dio `ERR_NAME_NOT_RESOLVED`. El DNS público resolvió `s2.diphuelva.es` a `195.77.52.38` el 18/10/2026. Una prueba puntual con `curl --resolve s2.diphuelva.es:443:195.77.52.38` preservó el nombre de host y validó TLS, obteniendo HTTP 200. No fijar esa IP en producción: puede cambiar. El bot debe exponer el fallo y reintentar cuando el DNS funcione.

## Almería: sumario ZK público

La [consulta oficial](https://app.dipalme.org/bop/publico.zul) requiere JavaScript. Se abrió con Playwright CLI usando Chrome del sistema. En el DOM, cada aviso es `tr.z-listitem` con siete celdas: BOP, fecha, PDF del boletín, PDF del índice, cabecera/título, número de edicto e icono del anuncio. El último boletín mostrado el 18/10 fue 201/2026 de 16/10/2026, con 17 avisos.

Para consultar otra fecha con Playwright:

```js
await page.goto('https://app.dipalme.org/bop/publico.zul');
await page.getByPlaceholder('dd/mm/aaaa').first().fill('15/10/2026');
await page.locator('a[title="Buscar registros con los parámetros indicados"]').click();
await page.locator('tr.z-listitem').first().waitFor();
const rows = await page.locator('tr.z-listitem').evaluateAll(rows =>
  rows.map(row => [...row.querySelectorAll('td')].map(cell => cell.innerText.trim()))
);
```

El 15/10 mostró BOP 200/2026, 17 avisos. El PDF individual se abre pulsando `td:last-child img` en la fila elegida; conviene capturar la URL de la nueva pestaña. No asumir que el nombre de fichero sea siempre `anuncio.pdf`: hay PDFs históricos con otros nombres. Los IDs de nodos ZK cambian en cada carga; el protocolo `/bop/zkau` usa sesión, `dtid` y UUID dinámicos.

Ejemplos del 15/10/2026:

| Edicto | Entidad y título | PDF comprobado en la pestaña |
| --- | --- | --- |
| 2792-2026 | Diputación de Almería — relación definitiva de admitidos, tribunal y fecha para una plaza de Técnico Medio en Juventud | [Anuncio 2792](https://app.dipalme.org/bop/services/manager/edicto/2026/2792/anuncio.pdf) |
| 2765-2026 | Ayuntamiento de Níjar — lista provisional para dos plazas de Administrativo, promoción interna | [Anuncio 2765](https://app.dipalme.org/bop/services/manager/edicto/2026/2765/anuncio.pdf) |

No se identificó un JSON o RSS público equivalente al de Huelva. El [archivo Pandora](https://app.dipalme.org/pandora/details.vm?lang=es&q=parent%3A0000010918&t=%2Balpha&view=boletines) cubre el BOP hasta el 16/10/2026, pero ofrece ejemplares, no metadatos de avisos fácilmente reutilizables. Para el bot de Almería, un extractor programado con navegador y publicación autenticada en WordPress es la opción comprobada.
