"""Reference parser for the public BOP Málaga daily summary.

This module does not fetch pages or solve the Turnstile protecting full edicts.
The caller must provide the HTML for a known publication date. Each result
links to that day's official summary, where its edict number is visible.
"""

from __future__ import annotations

from datetime import date
from html.parser import HTMLParser
import re


HOST = "www.bopmalaga.es"
_EMPLOYMENT = re.compile(
    r"\b(?:plazas?|bolsa(?:s)?(?: de (?:empleo|trabajo))?|oposici[oó]n|"
    r"proceso selectivo|oferta (?:p[uú]blica )?de empleo|OEP|OPE|"
    r"funcionari[oa]s?|personal laboral|cobertura temporal|provisi[oó]n de puestos?|"
    r"admitid[oa]s?|selecci[oó]n de personal)\b",
    re.I,
)
_EXCLUDE = re.compile(r"^(?:[^.]+\.\s*)?(?:nombramiento|cese|aprobaci[oó]n definitiva de la relaci[oó]n de puestos)", re.I)
_CVE = re.compile(r"^edicto\.php\?edicto=(\d{8}-\d{5}-\d{4}-\d{2})$")


def daily_url(day: date) -> str:
    return f"https://{HOST}/sumario.php?fecha={day:%d-%m-%Y}"


class _Summary(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.in_summary = False
        self.in_article = False
        self.in_time = False
        self.day: str | None = None
        self.parts: list[str] = []
        self.href = ""
        self.edict = ""
        self.rows: list[tuple[str, str, str]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        if tag == "div" and values.get("id") == "seccionSumario":
            self.in_summary = True
        if tag == "time" and not self.in_summary and values.get("datetime"):
            self.day = values["datetime"]
            self.in_time = True
        if self.in_summary and tag == "article":
            self.in_article, self.parts, self.href, self.edict = True, [], "", ""
        if self.in_article and tag == "a":
            self.href = values.get("href") or ""

    def handle_endtag(self, tag: str) -> None:
        if tag == "time":
            self.in_time = False
        if tag == "article" and self.in_article:
            title = re.sub(r"\s+", " ", " ".join(self.parts)).strip()
            self.rows.append((title, self.href, self.edict))
            self.in_article = False

    def handle_data(self, data: str) -> None:
        if self.in_article:
            self.parts.append(data)
            if "Edicto" in data:
                self.edict = data.strip()


def parse_summary(html_data: bytes, published: date) -> list[dict[str, str]]:
    parser = _Summary()
    parser.feed(html_data.decode("utf-8", errors="replace"))
    if parser.day != published.isoformat() or not parser.in_summary:
        raise ValueError("BOP Málaga: sumario ausente o fecha distinta")

    results = []
    for raw_title, href, edict in parser.rows:
        match = _CVE.fullmatch(href)
        if not match or not match[1].startswith(published.strftime("%Y%m%d")):
            continue
        title = re.sub(r"\s*\[\s*Edicto\s+\d+/\d+\s*\]\s*$", "", raw_title, flags=re.I)
        title = re.sub(r"\s+", " ", title).strip(" .")
        title = re.sub(r"\s+\.\s+", ". ", title)
        if not _EMPLOYMENT.search(title) or _EXCLUDE.search(title):
            continue
        results.append({
            "title": title[:300],
            "url": daily_url(published),
            "date": published.isoformat(),
            "excerpt": f"{edict}. Sumario oficial del BOP de Málaga; el texto completo del edicto requiere verificación interactiva.",
            "source": "bop",
            "cve": match[1],
        })
    return results
